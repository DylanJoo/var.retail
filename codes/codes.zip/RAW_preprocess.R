table=read.csv("D://lab/project3/data/output/spec_12.csv", nrow=10)
